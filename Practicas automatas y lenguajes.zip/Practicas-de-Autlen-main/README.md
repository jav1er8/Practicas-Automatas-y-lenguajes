Prácticas de la asignatura de Automatas y Lenguajes del 3º curso del grado de ingeniería informática en la Universidad Autónoma de Madrid
